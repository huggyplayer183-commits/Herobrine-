package com.herobrine;

import com.herobrine.entity.EntityHerobrine;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.relauncher.Side;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class SpawnHandler {
    private final Map<UUID, Long> lastSpawn = new HashMap<>();

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.side != Side.SERVER) return;
        EntityPlayer p = e.player;
        World w = p.world;
        if (p.ticksExisted % 20 != 0 || p.isSpectator()) return;
        if (w.provider.getDimension() != 0) return; // so no Overworld

        Long last = lastSpawn.get(p.getUniqueID());
        if (last != null && w.getTotalWorldTime() - last < HerobrineMod.cooldownMinutes * 1200L) return;

        if (w.rand.nextInt(HerobrineMod.spawnChance) != 0) return;

        // ja existe um Herobrine por perto?
        if (!w.getEntitiesWithinAABB(EntityHerobrine.class, p.getEntityBoundingBox().grow(120)).isEmpty()) return;

        Vec3d look = new Vec3d(p.getLookVec().x, 0, p.getLookVec().z).normalize();

        for (int attempt = 0; attempt < 8; attempt++) {
            double angle = w.rand.nextDouble() * Math.PI * 2;
            double dx = Math.cos(angle), dz = Math.sin(angle);

            // nao aparece "do nada" na frente do jogador
            if (look.x * dx + look.z * dz > 0.3) continue;

            int x = MathHelper.floor(p.posX + dx * HerobrineMod.watchDistance);
            int z = MathHelper.floor(p.posZ + dz * HerobrineMod.watchDistance);
            if (!w.isBlockLoaded(new BlockPos(x, 64, z))) continue;

            BlockPos pos = w.getTopSolidOrLiquidBlock(new BlockPos(x, 0, z));
            if (w.getBlockState(pos.down()).getMaterial().isLiquid()) continue;
            if (Math.abs(pos.getY() - p.posY) > 12) continue;
            if (!w.canSeeSky(pos)) continue;

            EntityHerobrine h = new EntityHerobrine(w);
            h.setLocationAndAngles(x + 0.5, pos.getY(), z + 0.5, 0, 0);
            if (!w.getCollisionBoxes(h, h.getEntityBoundingBox()).isEmpty()) continue;

            w.spawnEntity(h);
            lastSpawn.put(p.getUniqueID(), w.getTotalWorldTime());
            return;
        }
    }
}
