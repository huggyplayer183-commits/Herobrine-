package com.herobrine;

import com.herobrine.client.ClientSetup;
import com.herobrine.entity.EntityHerobrine;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.config.Configuration;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.registry.EntityRegistry;
import net.minecraftforge.fml.relauncher.Side;

@Mod(modid = HerobrineMod.MODID, name = "Herobrine Watcher", version = "1.0", acceptedMinecraftVersions = "[1.12.2]")
public class HerobrineMod {
    public static final String MODID = "herobrinewatcher";

    @Mod.Instance(MODID)
    public static HerobrineMod instance;

    // Configuravel em config/herobrinewatcher.cfg
    public static int spawnChance = 3000;     // chance 1 em N por segundo (por jogador)
    public static int watchDistance = 35;     // distancia em blocos
    public static int minDistance = 20;       // se o jogador chegar mais perto que isso, ele some
    public static int maxLifeSeconds = 45;    // tempo maximo visivel
    public static int stareSeconds = 3;       // segundos encarando ate ele sumir
    public static int cooldownMinutes = 20;   // intervalo minimo entre aparicoes

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        Configuration cfg = new Configuration(event.getSuggestedConfigurationFile());
        spawnChance = cfg.getInt("spawnChance", "general", spawnChance, 20, 1000000,
                "Chance de 1 em N, checada 1x por segundo por jogador. Maior = mais raro.");
        watchDistance = cfg.getInt("watchDistance", "general", watchDistance, 10, 60,
                "Distancia (blocos) em que ele aparece observando.");
        minDistance = cfg.getInt("minDistance", "general", minDistance, 2, 50,
                "Se voce chegar mais perto que isso, ele desaparece.");
        maxLifeSeconds = cfg.getInt("maxLifeSeconds", "general", maxLifeSeconds, 5, 600,
                "Tempo maximo que ele fica la.");
        stareSeconds = cfg.getInt("stareSeconds", "general", stareSeconds, 1, 60,
                "Segundos olhando direto para ele ate ele sumir.");
        cooldownMinutes = cfg.getInt("cooldownMinutes", "general", cooldownMinutes, 0, 600,
                "Tempo minimo entre aparicoes para o mesmo jogador.");
        if (cfg.hasChanged()) cfg.save();

        EntityRegistry.registerModEntity(new ResourceLocation(MODID, "herobrine"),
                EntityHerobrine.class, "herobrine", 0, instance, 64, 1, true);
        MinecraftForge.EVENT_BUS.register(new SpawnHandler());

        if (event.getSide() == Side.CLIENT) {
            ClientSetup.init();
        }
    }
}
