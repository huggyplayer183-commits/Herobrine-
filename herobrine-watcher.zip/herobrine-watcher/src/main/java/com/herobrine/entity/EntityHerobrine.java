package com.herobrine.entity;

import com.herobrine.HerobrineMod;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import javax.annotation.Nullable;

/** Herobrine: nunca ataca, nao se move, so observa e some. */
public class EntityHerobrine extends EntityCreature {
    private int stareTicks = 0;

    public EntityHerobrine(World world) {
        super(world);
        setSize(0.6F, 1.8F);
        setSilent(true);
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(20.0D);
        getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.0D);
        getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).setBaseValue(64.0D);
    }

    // Sem tasks de IA: nao anda, nao ataca.

    @Override
    public void onUpdate() {
        super.onUpdate();
        if (world.isRemote) return;

        EntityPlayer p = world.getClosestPlayerToEntity(this, 100.0D);
        if (p == null || ticksExisted > HerobrineMod.maxLifeSeconds * 20) {
            vanish();
            return;
        }

        getLookHelper().setLookPositionWithEntity(p, 30.0F, 30.0F);

        if (getDistance(p) < HerobrineMod.minDistance) {
            vanish();
            return;
        }

        // se o jogador encarar direto por alguns segundos, ele some
        Vec3d look = p.getLook(1.0F).normalize();
        Vec3d to = new Vec3d(posX - p.posX, (posY + 1.6D) - (p.posY + p.getEyeHeight()), posZ - p.posZ).normalize();
        if (look.dotProduct(to) > 0.99D && p.canEntityBeSeen(this)) {
            stareTicks++;
        } else if (stareTicks > 0) {
            stareTicks--;
        }
        if (stareTicks > HerobrineMod.stareSeconds * 20) {
            vanish();
        }
    }

    private void vanish() {
        setDead();
    }

    @Override
    public boolean attackEntityFrom(DamageSource source, float amount) {
        if (!world.isRemote) vanish(); // qualquer golpe faz ele sumir
        return false;
    }

    @Override public boolean canBePushed() { return false; }
    @Override protected boolean canDespawn() { return false; }

    /** Nao e salvo no mundo: nunca reaparece ao recarregar. */
    @Override
    public boolean writeToNBTOptional(NBTTagCompound compound) {
        return false;
    }

    @Nullable @Override protected SoundEvent getAmbientSound() { return null; }
    @Override protected SoundEvent getHurtSound(DamageSource s) { return SoundEvents.ENTITY_GENERIC_HURT; }
    @Nullable @Override protected SoundEvent getDeathSound() { return null; }
}
