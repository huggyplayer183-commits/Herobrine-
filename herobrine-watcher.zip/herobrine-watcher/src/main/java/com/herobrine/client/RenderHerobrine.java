package com.herobrine.client;

import com.herobrine.HerobrineMod;
import com.herobrine.entity.EntityHerobrine;
import net.minecraft.client.model.ModelPlayer;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.util.ResourceLocation;

public class RenderHerobrine extends RenderLiving<EntityHerobrine> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(HerobrineMod.MODID, "textures/entity/herobrine.png");

    public RenderHerobrine(RenderManager manager) {
        super(manager, new ModelPlayer(0.0F, false), 0.5F);
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityHerobrine entity) {
        return TEXTURE;
    }
}
