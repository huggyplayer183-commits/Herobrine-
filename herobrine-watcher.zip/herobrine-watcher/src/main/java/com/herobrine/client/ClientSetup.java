package com.herobrine.client;

import com.herobrine.entity.EntityHerobrine;
import net.minecraftforge.fml.client.registry.RenderingRegistry;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class ClientSetup {
    public static void init() {
        RenderingRegistry.registerEntityRenderingHandler(EntityHerobrine.class, RenderHerobrine::new);
    }
}
