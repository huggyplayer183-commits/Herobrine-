HEROBRINE WATCHER - Forge 1.12.2

COMO COMPILAR (precisa de Java 8 e internet)
1. Baixe o MDK oficial do Forge 1.12.2 (14.23.5.2854) em files.minecraftforge.net
2. Extraia o MDK numa pasta. Apague a pasta src/ dele.
3. Copie para la a pasta src/ e o build.gradle deste projeto (substituindo o do MDK).
4. Rode:  gradlew setupDecompWorkspace   e depois   gradlew build
5. O jar sai em build/libs/herobrine-watcher-1.0.jar -> coloque na pasta mods.

COMPORTAMENTO
- Aparece raramente (1 chance em 3000 por segundo, intervalo minimo de 20 min), so no Overworld, ao ar livre.
- Surge a 35 blocos, fora da sua linha de visao, parado e olhando para voce.
- Nunca ataca nem se move.
- Some se: voce chegar a menos de 20 blocos, encarar direto ~3s, bater nele ou passar de 45s.
- Ajuste tudo em config/herobrinewatcher.cfg
